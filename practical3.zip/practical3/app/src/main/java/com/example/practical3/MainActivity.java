package com.example.practical3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i("lifecycleTag","called from onCreate");
        Toast.makeText(MainActivity.this,"called from onStart",Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i("lifecycleTag", "called from onStop ");
        Log.i("lifecycleTag","called from onCreate");
        Toast.makeText(MainActivity.this,"called from onStop",Toast.LENGTH_LONG).show();



    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i("lifecycleTag","called from onPause");
        Log.i("lifecycleTag","called from onCreate");
        Toast.makeText(MainActivity.this,"called from onPause",Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i("liyecycleTag","called from onResume");
        Log.i("lifecycleTag","called from onCreate");
        Toast.makeText(MainActivity.this,"called from onResume",Toast.LENGTH_LONG).show();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i("lifecycle","called from onDestroy");
        Log.i("lifecycleTag","called from onCreate");
        Toast.makeText(MainActivity.this,"called from ondestroy",Toast.LENGTH_LONG).show();
    }
}